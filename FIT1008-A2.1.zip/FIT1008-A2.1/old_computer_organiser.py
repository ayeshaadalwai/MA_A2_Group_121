from __future__ import annotations

from computer import Computer

from data_structures.hash_table import LinearProbeTable
from double_key_table import DoubleKeyTable
from infinite_hash_table import InfiniteHashTable

from algorithms import mergesort

class ComputerOrganiser:

    def __init__(self) -> None:
        self.hash_table = LinearProbeTable()
        self.computer_list = []
        self.computer_values_ranking_list = []
        self.infinite_hash_table = InfiniteHashTable()
        self.tie = False

    def cur_position(self, computer: Computer) -> int:
        return self.binary_search(computer)

    def add_computers(self, computers: list[Computer]) -> None:
        self.computer_list += computers
        hacking = lambda computer : computer.hacking_difficulty
        risk = lambda computer : computer.risk_factor
        computer_lst = mergesort.mergesort(self.computer_list, hacking)
        self.computer_list = []
        computer_hash_table = DoubleKeyTable()
        
        for index in range(len(computer_lst)):
            if index != len(computer_lst) - 1 and computer_lst[index].hacking_difficulty == computer_lst[index + 1].hacking_difficulty:
                self.tie = True
            computer = computer_lst[index]
            computer_hash_table[str(computer.hacking_difficulty), str(computer.risk_factor)] = computer

        if not self.tie:
            self.computer_list += computer_lst
            return 
        
        self.tie = False
        order = lambda num : ord(num)
        sorted_computers_by_hack = computer_hash_table.keys()
        sorted_computers_by_hack = mergesort.mergesort(sorted_computers_by_hack, order)
        for hacking_dificulty in sorted_computers_by_hack:
            sorted_computers_risk_factor = mergesort.mergesort(computer_hash_table.values(hacking_dificulty), risk)
            risk_factor_table = DoubleKeyTable()

            for i in range(len(sorted_computers_risk_factor)):
                if i != len(sorted_computers_risk_factor) - 1 and sorted_computers_risk_factor[i].risk_factor == sorted_computers_risk_factor[i + 1].risk_factor:
                    self.tie = True
                computer = sorted_computers_risk_factor[i]
                risk_factor_table[str(computer.risk_factor), str(computer.name)] = computer

            if self.tie:
                self.tie = False 
                lexicograph_hash_table = InfiniteHashTable()
                sorted_computers_lex_lst = []

                for risk_factor in risk_factor_table.iter_keys():
                    same_risk_factor_lst = risk_factor_table.values(risk_factor)
                    for computer in same_risk_factor_lst:
                        computer_name = computer.name
                        lexicograph_hash_table[str(computer_name)] = computer
                        sorted_computer_names_lex_lst = lexicograph_hash_table.sort_keys()

                    for computer_name in sorted_computer_names_lex_lst:
                        sorted_computers_lex_lst.append(lexicograph_hash_table[computer_name])

                    self.computer_list += sorted_computers_lex_lst

            else:
                self.computer_list += sorted_computers_risk_factor

    def binary_search(self, computer_item: Computer) -> int:
        """
        Utilise the binary search algorithm to find the index where a particular element would be stored.

        :return: The index at which either:
            * This item is located, or
            * Where this item would be inserted to preserve the ordering.

        :complexity:
        Best Case Complexity: O(1), when middle index contains item.
        Worst Case Complexity: O(log(N)), where N is the length of l.
        """
        return self._binary_search_aux(computer_item, 0, len(self.computer_list))

    def _binary_search_aux(self, computer_item: Computer, lo: int, hi: int) -> int:
        """
        Auxilliary method used by binary search.
        lo: smallest index where the return value could be.
        hi: largest index where the return value could be.
        """
        if lo == hi:
            raise KeyError(computer_item.name)
        mid = (hi + lo) // 2
        if self.computer_list[mid] == computer_item:
            return mid
        else:
            return self.compare_by_hacking_difficulty(computer_item, lo, hi, mid)

    def compare_by_hacking_difficulty(self, computer_item: Computer, lo: int, hi: int, mid: int):
        if self.computer_list[mid].hacking_difficulty > computer_item.hacking_difficulty:
            # Item would be before mid
            return self._binary_search_aux(computer_item, lo, mid)
        
        elif self.computer_list[mid].hacking_difficulty < computer_item.hacking_difficulty:
            # Item would be after mid
            return self._binary_search_aux(computer_item, mid+1, hi)
        
        elif self.computer_list[mid].hacking_difficulty == computer_item.hacking_difficulty:
            return self.compare_by_risk_factor(computer_item, lo, hi, mid)
        
        raise ValueError(f"Comparison operator in hacking difficulty poorly implemented {computer_item} and {self.computer_list[mid]} cannot be compared.")
        
    def compare_by_risk_factor(self, computer_item: Computer, lo: int, hi: int, mid: int):
        if self.computer_list[mid].risk_factor > computer_item.risk_factor:
            # Item would be before mid
            return self._binary_search_aux(computer_item, lo, mid)
        
        elif self.computer_list[mid].risk_factor < computer_item.risk_factor:
            # Item would be after mid
            return self._binary_search_aux(computer_item, mid+1, hi)
        
        elif self.computer_list[mid].risk_factor == computer_item.risk_factor:
            return self.compare_by_lexicograph(computer_item, lo, hi, mid)
        
        raise ValueError(f"Comparison operator in risk factor poorly implemented {computer_item} and {self.computer_list[mid]} cannot be compared.")
        
    def compare_by_lexicograph(self, computer_item: Computer, lo: int, hi: int, mid: int):
        inf_hash_table_for_lex = InfiniteHashTable()
        for computer in [self.computer_list[mid], computer_item]:
            inf_hash_table_for_lex[computer.name] = computer 

        sorted_list = inf_hash_table_for_lex.sort_keys()
        
        if sorted_list.index(self.computer_list[mid].name) > sorted_list.index(computer_item.name):
            # Item would be before mid
            return self._binary_search_aux(computer_item, lo, mid)
        
        elif sorted_list.index(self.computer_list[mid].name) < sorted_list.index(computer_item.name):
            # Item would be after mid
            return self._binary_search_aux(computer_item, mid+1, hi)
        
        raise ValueError(f"Comparison operator in lexicograph poorly implemented {computer_item} and {self.computer_list[mid]} cannot be compared.")
