# 24-S1-A2
AI Viruses Assignment

## Running the Tests

`python run_tests.py`

## Running just some of the Tests

`python run_tests.py 1` will run all tests marked with `@number("1.x")`.
