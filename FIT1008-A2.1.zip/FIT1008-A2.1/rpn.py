from data_structures.linked_stack import LinkedStack

if __name__ == "__main__":
    oper_stack = LinkedStack()
    operations = "7 3 + 8 - 2 * 2 /"
    
    operations_list = operations.split() 
    '''
    for char in operations_list:
        print(char)

        if type(char) in (float, int):
            oper_stack.push(char) 
        
        else:
            num1 = oper_stack.pop()
            num2 = oper_stack.pop() 

            if char == '+':
                res = num2 + num1 

            elif char == '-':
                res = num2 - num1 

            elif char == '*':
                res = num2 * num1 

            elif char == '/':
                res = num2 / num1 

            oper_stack.push(res)
    '''
    for token in operations_list:
        if token in ['+', '-', '*', '/']:
            num1 = oper_stack.pop()
            num2 = oper_stack.pop() 
            res = eval(str(num2) + token + str(num1))
            oper_stack.push(res)
        else:
            oper_stack.push(token)
    print(oper_stack.pop()) 
        