from __future__ import annotations
from typing import Generic, TypeVar

from data_structures.referential_array import ArrayR
from data_structures.linked_stack import LinkedStack

from algorithms.mergesort import mergesort

K = TypeVar("K")
V = TypeVar("V")


class InfiniteHashTable(Generic[K, V]):
    """
    Infinite Hash Table.

    Type Arguments:
        - K:    Key Type. In most cases should be string.
                Otherwise `hash` should be overwritten.
        - V:    Value Type.

    Unless stated otherwise, all methods have O(1) complexity.
    """

    TABLE_SIZE = 27

    def __init__(self, level: int = 0) -> None:
        self.array: ArrayR[tuple[K, V] | None] = ArrayR(self.TABLE_SIZE)
        self.count = 0
        self.level = level
        self.location_lst = []
        self.str = "{"
        self.sorted_lst = []
    
    def hash(self, key: K) -> int:
        if self.level < len(key):
            return ord(key[self.level]) % (self.TABLE_SIZE-1)
        return self.TABLE_SIZE-1

    def __getitem__(self, key: K) -> V:
        """
        Get the value at a certain key

        :raises KeyError: when the key doesn't exist.
        """
        return self.get_item_aux(self, key, 0)
    
    def get_item_aux(self, hash_table:InfiniteHashTable, key:K, level: int):
        position = hash_table.hash(key)
        if hash_table.array[position] is None:
            raise KeyError(key)
        
        elif isinstance(hash_table.array[position], tuple) and hash_table.array[position][0] == key:
            self.location_lst.append(position)
            if isinstance(hash_table.array[position][1], InfiniteHashTable):
                return self.get_item_aux(hash_table.array[position][1], key, level + 1)
            else:
                return hash_table.array[position][1] 
        
        elif isinstance(hash_table.array[position], tuple) and hash_table.array[position][0] == key[:level + 1]:
            if isinstance(hash_table.array[position][1], InfiniteHashTable):
                self.location_lst.append(position)
                return self.get_item_aux(hash_table.array[position][1], key, level + 1)
            else:
                raise KeyError(key)
            
        else: 
            raise KeyError(key)

    def __setitem__(self, key: K, value: V) -> None:
        """
        Set an (key, value) pair in our hash table.
        """
        '''
        hash_table = self
        while True:
            position = hash_table.hash(key)
            if hash_table.array[position] is None:
                hash_table.array[position] = (key, value)
                break 
            elif isinstance(hash_table.array[position], tuple) and isinstance(hash_table[position][1], V):
                first_key = hash_table.array[position]
                level = self.level + 1
                hash_table.array[position] = (key[0], InfiniteHashTable(level))
        '''
        return self.set_item_aux(self, key, value, 0)

    def set_item_aux(self, hash_table:InfiniteHashTable, key:K, value:V, level: int):
        position = hash_table.hash(key)
        if hash_table.array[position] is None:
            hash_table.count += 1
            hash_table.array[position] = (key, value) 
        elif isinstance(hash_table.array[position], tuple) and not isinstance(hash_table.array[position][1], InfiniteHashTable):
            first_item = hash_table.array[position]
            hash_table.array[position] = (first_item[0][:level + 1], InfiniteHashTable(level + 1))
            hash_table.count += 1
            self.set_item_aux(hash_table.array[position][1], first_item[0], first_item[1], level + 1)
            self.set_item_aux(hash_table.array[position][1], key, value, level + 1)

        elif isinstance(hash_table.array[position], tuple) and isinstance(hash_table.array[position][1], InfiniteHashTable):
            hash_table.count += 1
            self.set_item_aux(hash_table.array[position][1], key, value, level + 1)

    def __delitem__(self, key: K) -> None:
        """
        Deletes a (key, value) pair in our hash table.

        :raises KeyError: when the key doesn't exist.
        """
        location_list = self.get_location(key)
        hash_tables_path_stack = LinkedStack()
        hash_table = self
        hash_table.count -= 1
        if len(location_list) == 1:
            self.array[location_list[0]] = None 
            return
        
        for i in (range(len(location_list) - 1)):
            hash_tables_path_stack.push(hash_table)
            hash_table = hash_table.array[location_list[i]][1]
            hash_table.count -= 1
        
        hash_table.array[location_list[-1]] = None 

        if len(hash_table) == 1:
            for j in range(len(hash_table.array)):
                item = hash_table.array[j]
                if item is not None:
                    only_item = item 
                    break 
            
            if not isinstance(only_item[1], InfiniteHashTable):
                location_list = self.get_location(only_item[0])
                list_index = len(location_list) - 2
                while not hash_tables_path_stack.is_empty():
                    hash_table = hash_tables_path_stack.pop()

                    if len(hash_table.array[location_list[list_index]][1]) <= 1:
                        hash_table.array[location_list[list_index]] = only_item
                        list_index -= 1
                    else:
                        break

    def __len__(self) -> int:
        return self.count

    def __str__(self) -> str:
        """
        String representation.

        Not required but may be a good testing tool.
        """
        for i in range(len(self.array)):
            item = self.array[i]
            if item is not None:
                self.str += f"{item[0]}: "
                if isinstance(item[1], InfiniteHashTable):
                    self.str += '{'
                    self.str_aux(item[1])
                    self.str += "}"
                else:
                    self.str += f"{item[1]}"
            
            else:
                self.str += "None: None"

            if i == len(self.array) - 1:
                break 
            else:
                self.str += "          "
        self.str += '}'
        return self.str
        
    def str_aux(self, hash_table):
        for j in range(len(hash_table.array)):
            item1 = hash_table.array[j]
            if item1 is not None:
                self.str += f"{item1[0]}: "
                if isinstance(item1[1], InfiniteHashTable):
                    self.str += '{'
                    self.str_aux(item1[1])
                    self.str += "}"
                else:
                    self.str += f"{item1[1]}"

                if j == len(hash_table.array) - 1:
                    break 
                else:
                    self.str += " "


    def get_location(self, key) -> list[int]:
        """
        Get the sequence of positions required to access this key.

        :raises KeyError: when the key doesn't exist.
        """
        self.location_lst = []
        self.get_item_aux(self, key, 0)
        location_list = self.location_lst
        return location_list

    def __contains__(self, key: K) -> bool:
        """
        Checks to see if the given key is in the Hash Table

        :complexity: See linear probe.
        """
        try:
            _ = self[key]
        except KeyError:
            return False
        else:
            return True

    def sort_keys(self, current = None) -> list[str]:
        """
        Returns all keys currently in the table in lexicographically sorted order.
        """
        if current == None:
            current = self
        return self.sort_keys_aux(current, [])
    
    def sort_keys_aux(self, current_table: InfiniteHashTable | None = None, sorted_list : list = []):
        for i in range(len(current_table.array)):
            item = current_table.array[i] 
            if item is not None:
                if type(item) == tuple:
                    if isinstance(item[1], InfiniteHashTable):
                        sorted_list = self.sort_keys_aux(item[1], sorted_list)
                    
                    else:
                        sorted_list.append(item[0])
        order = lambda key : self.key_order(key, current_table.level)
        sorted_list = mergesort(sorted_list, order)
        return sorted_list
    
    def key_order(self, key, level):
        prime = 127
        if level < len(key):
            return ord(key[level]) % prime 
        return 3
